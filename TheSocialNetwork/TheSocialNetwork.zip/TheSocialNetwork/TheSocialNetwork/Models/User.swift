//
//  User.swift
//  TheSocialNetwork
//
//  Created by Андрей Калюжный on 04.09.2021.
//

import UIKit
import RealmSwift




final class User: ProtocolUser {
    //var avatar: String?
    //var arrayFotos: [String]?
    var arrayFotos: [UIImage]?
    var idUser: Int64?
    var name: String
    var age: UInt16
    var avatar: UIImage?
    
    
    
    init(name: String, age: UInt16, avatar: UIImage?, arrayFotos: [UIImage]?) {
        self.name = name
        self.age = age
        self.avatar = avatar
        self.arrayFotos = arrayFotos
    }
    
    init(name: String, age: UInt16, avatar: UIImage?) {
        self.name = name
        self.age = age
        self.avatar = avatar
    }
    
    init(name: String, age: UInt16) {
        self.name = name
        self.age = age
    }
    
    init(name: String, age: UInt16, idUser: Int64?) {
        self.name = name
        self.age = age
        self.idUser = idUser
    }
    
//    enum CodingKeys: String, CodingKey {
//        //case idUser = "id"
//        case name = "first_name"
//    }
}
