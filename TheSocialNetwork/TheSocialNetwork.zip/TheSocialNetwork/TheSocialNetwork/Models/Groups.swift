//
//  Groups.swift
//  TheSocialNetwork
//
//  Created by Андрей Калюжный on 06.09.2021.
//

import UIKit

protocol ProtocolGroup: AnyObject {
    var name: String { get set }
    var avatar: UIImage? { get set }
}

final class Group: ProtocolGroup {
    var avatar: UIImage?
    var name: String
    
    init(name: String, avatar: UIImage?) {
        self.name = name
        self.avatar = avatar
    }
}
