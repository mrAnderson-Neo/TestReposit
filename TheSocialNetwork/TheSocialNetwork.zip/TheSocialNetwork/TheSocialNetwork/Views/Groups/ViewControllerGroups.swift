//
//  ViewControllerGroups.swift
//  TheSocialNetwork
//
//  Created by Андрей Калюжный on 13.09.2021.
//

import UIKit

class ViewControllerGroups: UIViewController {
    
    var arrayGroups = [ProtocolGroup]()
    @IBOutlet var buttonAllgroups: UIBarButtonItem!
    
    let resueSegue = "fromGroupsToAllGroups"
    
    //var handler: (([ProtocolGroup]) -> Void)?
    
    let resueXibCell = "TableViewCell"
    
    @IBOutlet var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        arrayGroups = DataStorage.dataStorage.arrayGroups

        self.tableView.register(UINib(nibName: resueXibCell, bundle: nil), forCellReuseIdentifier: resueXibCell)
        
        //buttonAllgroups.add
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case resueSegue:
            if let editScreen = segue.destination as? ViewControllerAllGroups {
                editScreen.groupsThatHaveAUser = arrayGroups
                editScreen.completionHandler = { [weak self] arrGroups in
                    self?.arrayGroups.append(arrGroups[0])
                    self?.tableView.reloadData()
                }
            }
        default:
            break
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


// MARK: - DELEGATE
extension ViewControllerGroups: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}

// MARK: - DATASOURCE
extension ViewControllerGroups: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrayGroups.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: resueXibCell) as? TableViewCell else {
            return UITableViewCell()
        }
        
        let foundGroup = arrayGroups[indexPath.row]
        
        cell.configure(textName: foundGroup.name, avatar: foundGroup.avatar, changeLabelAge: 0)
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            arrayGroups.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
}
